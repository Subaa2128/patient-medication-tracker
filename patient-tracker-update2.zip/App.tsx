import { StyleSheet, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { NavigationContainer } from '@react-navigation/native'
import Profile from './src/pages/Patient/Profile';
import HomeIcon from './src/assets/icons/HomeIcon'
import AccountIcon from './src/assets/icons/AccountIcon';
import LoginModal from './src/screens/Login';
import { useEffect, useState } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuthStore } from './src/store/authStore';
import UserHome from './src/pages/Patient/UserHome';
import Home from './src/pages/Doctor/Home';
import DoctorProfile from './src/pages/Doctor/DoctorProfile';
const Tab = createBottomTabNavigator()
const Stack = createNativeStackNavigator()

const TabNavigator = () => {
  const { userType } = useAuthStore();
  return (
    <Tab.Navigator >
      <Tab.Screen name='Home' options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({ focused, color }) =>
          focused ? (
            <View style={{ backgroundColor: 'white', borderRadius: 50 }}>
              <HomeIcon color={color} width={40} height={40} />
            </View>
          ) : (
            <HomeIcon color={color} width={40} height={40} />
          ),
        headerShown: true,
      }} component={userType==='patients'?UserHome:Home} />
      <Tab.Screen name='Profile' options={{
        tabBarLabel: 'Profile',
        tabBarIcon: ({ focused, color }) =>
          focused ? (
            <View style={{ backgroundColor: 'white', borderRadius: 50 }}>
              <AccountIcon color={color} width={40} height={40} />
            </View>
          ) : (
            <AccountIcon color={color} width={40} height={40} />
          ),
        headerShown: true,
      }}
        component={userType==='patients'?Profile:DoctorProfile} />
    </Tab.Navigator>
  )
}

function StackNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name='Stack'
        options={{
          headerShown: false,
          // headerBackground: () => <Header />,
        }}
        component={TabNavigator}
      />
    </Stack.Navigator>
  )
}

export default function App() {
  const { isLoggedIn, setIsLoggedIn } = useAuthStore();
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const storedProfile = await AsyncStorage.getItem('loggedInUser');
      if (storedProfile) {
        setProfileData(JSON.parse(storedProfile));
      }
    };

    fetchProfile();
  }, []);
  useEffect(() => {
    const requestPermissions = async () => {
      if (Device.isDevice) {
        const { status } = await Notifications.getPermissionsAsync();
        if (status !== 'granted') {
          await Notifications.requestPermissionsAsync();
        }
      }
    };

    requestPermissions();
  }, []);

  return (
    <NavigationContainer>
      {!isLoggedIn || profileData === null ? (
        <LoginModal isVisible={!isLoggedIn} onClose={() => setIsLoggedIn(true)} onLoginSuccess={function (): void {
          throw new Error('Function not implemented.');
        } } />
      ) : (
        <StackNavigator />
      )}
    </NavigationContainer>
  );
}


